(function() {
  'use strict';
  angular.module('DeezerApp', [
    'ui.router'
  ]);
})();
